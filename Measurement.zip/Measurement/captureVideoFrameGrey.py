'''This program can be used to collect ionizing radiation events
on a CMOS pixel array in a consumer device camera'''

import cv2
import time
import numpy as np

# In a linux environment, check the camera id first with v4l driver
# e.g. in bash command line type 'v4l2-ctl --list-devices'
cap = cv2.VideoCapture(1)

# Initiale a zero array
sumArray = np.zeros(480*640).reshape(480,640)
print (sumArray) # OPTION

# Check whether user selected camera is opened successfully.
if not (cap.isOpened()):
    print ("Could not open video device")

# To set the resolution
#cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 640)
#cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 480)

# Start timing
start = time.time()

# Name of the file for writing data
testFile = 'source2.csv'
# Set the number of frames captured in one measurement
cycleNo = 1000

for i in range(cycleNo): 

    # Capture frame data
    ret, frame = cap.read()
    # Extracting monochrome data
    grayFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Summing monochrome data into numpy array
    sumArray = sumArray + grayFrame

    # OPTION: Displaying the resulting frame while capturing
    cv2.imshow('preview',grayFrame)

    # Waits for a user input to quit the application
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# End timing
end = time.time()

print ('measurement time: ',end-start)

# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()

# OPTION: Print some information on summed array
print (grayFrame.shape)
print (grayFrame)
print (sumArray)

# Writing the summed array to file
np.savetxt('1/'+testFile, sumArray, delimiter=' ')

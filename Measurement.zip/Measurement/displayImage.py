'''This program can be used for interactive display
of measurement data in 2D, 3D or both'''

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import matplotlib.cm as cm
import matplotlib.ticker as ticker

class pixelscan:

    def __init__(self, filename):

        self.filename = filename

        fh = open(filename)
        fhArray = fh.readlines()
        fh.close()

        data_array = []

        self.fig = plt.figure()

        for i,j in enumerate(fhArray):
            data_array = data_array+[j.replace('\n','').split(' ')]

        self.data_array = np.array(data_array).astype('float')
    
    def image2D(self, cmapVar = plt.cm.nipy_spectral_r):# Method to display image only in 2D

        ax = self.fig.add_subplot(1, 1, 1)

        plane = ax.imshow(self.data_array, cmap=cmapVar)
        self.fig.colorbar(plane)
        ax.set_title(self.filename) # OPTION
        plt.show()
    
    def image3D(self, log=False, minz=0, maxz=256, cmapVar = plt.cm.nipy_spectral_r):# Method to display image only in 3D

        if log == True:
            Z = np.log(self.data_array)
        else:
            Z = self.data_array

        ax = self.fig.add_subplot(1, 1, 1, projection='3d')

        X = np.arange(self.data_array.shape[1])
        Y = np.arange(self.data_array.shape[0])
        X, Y = np.meshgrid(X, Y)

        surf = ax.plot_surface(X, Y, Z, cmap=cmapVar, alpha=0.7)
        
        ax.view_init(30, 40)                          # Angles of viewing
        ax.set_title(self.filename) # OPTION

        self.fig.colorbar(surf)
        plt.tight_layout()
        plt.show()

    def image2Dand3D(self, log=False, cmapVar = plt.cm.nipy_spectral_r):# Method to display image both in 2D and 3D

        self.fig.set_figheight(5)
        self.fig.set_figwidth(12)

        if log == True:
            Z = np.log(self.data_array)
        else:
            Z = self.data_array

        ax1 = self.fig.add_subplot(1, 2, 1, projection='3d')
        
        X = np.arange(self.data_array.shape[1])
        Y = np.arange(self.data_array.shape[0])
        X, Y = np.meshgrid(X, Y)

        surf = ax1.plot_surface(X, Y, Z, cmap=cmapVar, alpha=0.9)

        ax1.view_init(30, 40)                          # Angles of viewing
        ax1.set_title(self.filename) # OPTION

        self.fig.colorbar(surf)

        ax2 = self.fig.add_subplot(1, 2, 2)

        img = ax2.imshow(self.data_array.T, cmap=cmapVar)
        self.fig.colorbar(img)
        ax2.set_title(self.filename)

        plt.tight_layout()
        plt.show()

# Instantiate the data: acquired measurement data from file
data_array = pixelscan('source1.csv')

# Choose any method of display
# (Note: color map can be changed by passing new map variable:
# e.g. data_array.image2Dand3D(cmapVar = plt.cm.Greys)
data_array.image2Dand3D()
#data_array.image2D()
#data_array.image3D()

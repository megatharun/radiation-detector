'''This program can be used to collect each summarized properties
of CMOS pixel array data from a consumer device camera'''

import cv2
import time
import numpy as np

# In a linux environment, check the camera id first with v4l driver
# e.g. in bash command line type 'v4l2-ctl --list-devices'
cap = cv2.VideoCapture(1)

# Initiale a zero array
sumArray = np.zeros(480*640).reshape(480,640)
print (sumArray) # OPTION

# Check whether user selected camera is opened successfully.
if not (cap.isOpened()):
    print ("Could not open video device")

# To set the resolution
#cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 640)
#cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 480)


# Name of the file for writing data
testFile = 'list_of_record_summary.csv'
# Set the number of frames captured in one measurement
cycleNo = 1000

# Open file for writing
fw = open(testFile, 'w')
# Writing the header file first
fw.write('Max Array'+' '+'Min Array'+ ' '+'Avg Array'+\
' '+'Sum Array'+'\n')

# Setting threshold variable
thrs = 8
# Start timing
start = time.time()

for i in range(cycleNo):

    # Capture frame data
    ret, frame = cap.read()
    # Extracting monochrome data
    grayFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Set data threshold
    grayFrame = (grayFrame>thrs)*grayFrame

    # Acquired array properties    
    maxArray = grayFrame.max()
    minArray = grayFrame.min()
    avgArray = grayFrame.mean()
    sumArray = grayFrame.sum()

    # Writing array properties for each data recorded to file
    fw.write(str(maxArray)+' '+str(minArray)+ ' '+str(avgArray)+\
    	' '+str(sumArray)+'\n')
    	
    # OPTION: print array properties for each data recorded
    #print (maxArray,'  ',minArray,'  ',avgArray,'  ',sumArray)

    # Waits for a user input to quit the application
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Close the opened file
fw.close()

# End timing
end = time.time()

print ('masa: ',end-start)

# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()
